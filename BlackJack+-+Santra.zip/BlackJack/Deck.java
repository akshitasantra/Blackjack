import java.util.Stack;
import java.util.Collections;
public class Deck
{
    Stack<Card> deck;
    public Deck(){
        deck = new Stack<Card>();
        for(int i = 1; i <= 52; i++){
            if(i == 1){
                deck.push(new Card(i, "♠", "A"));
            }
            else if(i < 11){
                deck.push(new Card(i, "♠", ""+i));
            }
            else if(i == 11){
                deck.push(new Card(10, "♠", "J"));
            }
            else if(i == 12){
                deck.push(new Card(10, "♠", "Q"));
            }
            else if(i == 13){
                deck.push(new Card(10, "♠", "K"));
            }
            else if(i == 14){
                deck.push(new Card(i, "♣", "A"));
            }
            else if(i < 24){
                deck.push(new Card(i%13, "♣", ""+i%13));
            }
            else if(i == 24){
                deck.push(new Card(10, "♣", "J"));
            }
            else if(i == 25){
                deck.push(new Card(10, "♣", "Q"));
            }
            else if(i == 26){
                deck.push(new Card(10, "♣", "K"));
            }
            else if(i == 36){
                deck.push(new Card(i, "❤", "A"));
            }
            else if(i < 37){
                deck.push(new Card(i%13, "❤", ""+i%13));
            }
            else if(i == 37){
                deck.push(new Card(10, "❤", "J"));
            }
            else if(i == 38){
                deck.push(new Card(10, "❤", "Q"));
            }
            else if(i == 39){
                deck.push(new Card(10, "❤", "K"));
            }
            else if(i == 40){
                deck.push(new Card(i, "♦", "A"));
            }
            else if(i < 50){
                deck.push(new Card(i%13, "♦", ""+i%13));
            }
            else if(i == 50){
                deck.push(new Card(10, "♦", "J"));
            }
            else if(i == 51){
                deck.push(new Card(10, "♦", "Q"));
            }
            else if(i == 52){
                deck.push(new Card(10, "♦", "K"));
            }
        }
        Collections.shuffle(deck);
    }

    public Card dealCard(){
        if(deck.empty()){
            resetDeck();
        }
        return deck.pop();
    }

    public void resetDeck(){
        deck = new Stack<Card>();
        for(int i = 1; i <= 52; i++){
            if(i < 11){
                deck.push(new Card(i, "♠", ""+i));
            }
            else if(i == 11){
                deck.push(new Card(10, "♠", "J"));
            }
            else if(i == 12){
                deck.push(new Card(10, "♠", "Q"));
            }
            else if(i == 13){
                deck.push(new Card(10, "♠", "K"));
            }
            else if(i < 24){
                deck.push(new Card(i%13, "♣", ""+i));
            }
            else if(i == 24){
                deck.push(new Card(10, "♣", "J"));
            }
            else if(i == 25){
                deck.push(new Card(10, "♣", "Q"));
            }
            else if(i == 26){
                deck.push(new Card(10, "♣", "K"));
            }
            else if(i < 37){
                deck.push(new Card(i%13, "❤", ""+i));
            }
            else if(i == 37){
                deck.push(new Card(10, "❤", "J"));
            }
            else if(i == 38){
                deck.push(new Card(10, "❤", "Q"));
            }
            else if(i == 39){
                deck.push(new Card(10, "❤", "K"));
            }
            else if(i < 50){
                deck.push(new Card(i%13, "♦", ""+i));
            }
            else if(i == 50){
                deck.push(new Card(10, "♦", "J"));
            }
            else if(i == 51){
                deck.push(new Card(10, "♦", "Q"));
            }
            else if(i == 52){
                deck.push(new Card(10, "♦", "K"));
            }
        }
        Collections.shuffle(deck);
    }
}