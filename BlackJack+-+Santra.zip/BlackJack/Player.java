import java.util.ArrayList;

public class Player
{
    String name;
    static ArrayList<Card> hand;
    public Player(String n){
        name = n;
        hand = new ArrayList<Card>();
    }

    public static int total(){
        int sum = 0;
        for(int i = 0; i < hand.size(); i++){
            sum+=hand.get(i).value;
        }
        return sum;
    }

    public void printHand(){
        System.out.print("Your hand:");
        for(int i = 0; i < hand.size(); i++){
            System.out.print(" " + hand.get(i).value + hand.get(i).suit);
        }
        System.out.println();
    }

    public static void calculatePlayerValue(){
        if(hand.get(hand.size()-1).value == 1 && (total() +10 < 21)){
            hand.get(hand.size()-1).value = 11;
        }
    }
}