import java.util.*;
public class Blackjack
{
    static ArrayList<Card> PCHand = new ArrayList<Card>();
    static Scanner scan = new Scanner(System.in);
    static Player player;
    static Deck deck = new Deck();
    static boolean playing = true;
    static int wins = 0;
    static int losses = 0;
    static boolean roundOver = false;
    public static void main(String[] args){
        System.out.println("Welcome to Blackjack!!! Enter your name: ");
        player = new Player(scan.nextLine());
        while(playing){
            roundOver = false;
            player.hand.clear();
            PCHand.clear();
            dealPlayerCard();
            PCHand.add(deck.dealCard());
            calculatePCValue();
            System.out.println("The Computer is dealt a card face-down");
            dealPlayerCard();
            PCHand.add(deck.dealCard());
            calculatePCValue();
            System.out.println("The Computer's next face-up card is: " + PCHand.get(1).toString());
            if(player.total() == 21){
                playerWin();
                continue;
            }
            System.out.println("hit or stay");
            String answer = scan.nextLine();
            while(answer.equals("hit")){
                dealPlayerCard();
                if(player.total() == 21){
                    playerWin();
                    answer = "";
                    roundOver = true;
                    continue;
                }
                else if(player.total() > 21){
                    PCWin();
                    answer = "";
                    roundOver = true;
                    continue;
                }
                System.out.println("hit or stay");
                answer = scan.nextLine();
            }
            if(roundOver){
                continue;
            }
            System.out.println("Player turn ends.");
            System.out.println("Computer turn begins.");
            if(PCtotal() > 16){
                System.out.println("The computer stays.");
            }
            while(PCtotal()<= 16){
                System.out.println("The computer hits.");
                PCHand.add(deck.dealCard());
                calculatePCValue();
                System.out.println("The Computer's next face-up card is: " + PCHand.get(PCHand.size()-1).toString());
                if(PCtotal() == 21){
                    PCWin();
                    roundOver = true;
                }
                else if(PCtotal() > 21){
                    System.out.println("Computer busted");
                    playerWin();
                    roundOver = true;
                }
            }
            if(roundOver){
                continue;
            }
            System.out.println("Computer turn ends." + "\n");
            System.out.println("Player card total: " + player.total());
            System.out.println("Computer card total: " + PCtotal());
            if(PCtotal() >= player.total()){
                PCWin();
                continue;
            }
            else{
                playerWin();
                continue;
            }
        }
        System.out.println("Thank you for playing Blackjack!");
    }

    public static int PCtotal(){
        int sum = 0;
        for(int i = 0; i < PCHand.size(); i++){
            sum+=PCHand.get(i).value;
        }
        return sum;
    }

    public static void calculatePCValue(){
        if(PCHand.get(PCHand.size()-1).value == 1 && (PCtotal() +10 < 21)){
            PCHand.get(PCHand.size()-1).value = 11;
        }
    }

    public static void playerWin(){
        System.out.println("You won this round!");
        wins++;
        System.out.println("Score: " + "\n" + wins + " wins" +  "\n" + losses + " losses" +  "\n");
        System.out.println("Would you like to play again? y or n");
        if(scan.nextLine().equals("n")){
            playing = false;
        }
        else{
            System.out.println("New round. Good luck :)");
        }
    }

    public static void PCWin(){
        if(player.total() > 21){
            System.out.println("You busted");
        }
        System.out.println("You lost");
        losses++;
        System.out.println("Score: " + "\n" + wins + " wins" +  "\n" + losses + " losses");
        System.out.println("Would you like to play again? y or n");
        if(scan.nextLine().equals("n")){
            playing = false;
        }
        else{
            System.out.println("New round. Good luck :)");
        }
    }

    public static void dealPlayerCard(){
        player.hand.add(deck.dealCard());
        player.calculatePlayerValue();
        System.out.println("Your card is: " + player.hand.get(player.hand.size()-1).toString());
        player.printHand();
    }
}
