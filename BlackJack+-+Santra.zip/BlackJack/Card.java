public class Card
{
    int value;
    String suit;
    String faceValue;
    public Card(int v, String s, String f){
        value = v;
        suit = s;
        faceValue = f;
    }
    public String toString(){
        return faceValue + suit;
    }
}
